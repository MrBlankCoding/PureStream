import "./styles.css";
import { showToast } from "./ui.js";
import { createIcons, icons } from "lucide";
import { BACKEND_URL, getRelativePath, getBackendMode, setBackendMode, IS_PACKAGED } from "./config.js";

createIcons({ icons });

const serverLocalBtn = document.getElementById("server-local") as HTMLButtonElement;
const serverHostedBtn = document.getElementById("server-hosted") as HTMLButtonElement;

function updateServerButtons() {
    if (!IS_PACKAGED) {
        if (serverLocalBtn) serverLocalBtn.parentElement?.classList.add("hidden");
        return;
    }
    
    const mode = getBackendMode();
    if (mode === 'local') {
        serverLocalBtn.className = "text-[10px] uppercase tracking-widest px-2 py-1 rounded transition-colors bg-blue-600/20 text-blue-400 border border-blue-500/40";
        serverHostedBtn.className = "text-[10px] uppercase tracking-widest px-2 py-1 rounded transition-colors text-gray-500 hover:text-gray-300";
    } else {
        serverHostedBtn.className = "text-[10px] uppercase tracking-widest px-2 py-1 rounded transition-colors bg-blue-600/20 text-blue-400 border border-blue-500/40";
        serverLocalBtn.className = "text-[10px] uppercase tracking-widest px-2 py-1 rounded transition-colors text-gray-500 hover:text-gray-300";
    }
}

if (serverLocalBtn && serverHostedBtn) {
    serverLocalBtn.onclick = () => {
        setBackendMode('local');
        window.location.reload();
    };
    serverHostedBtn.onclick = () => {
        setBackendMode('hosted');
        window.location.reload();
    };
    updateServerButtons();
}

const createUsernameInput = document.getElementById("create-username") as HTMLInputElement;
const joinUsernameInput = document.getElementById("join-username") as HTMLInputElement;
const roomCodeInput = document.getElementById("room-code-input") as HTMLInputElement;
const createRoomBtn = document.getElementById("create-room-btn") as HTMLButtonElement;
const joinRoomBtn = document.getElementById("join-room-btn") as HTMLButtonElement;

const urlParams = new URLSearchParams(window.location.search);
const urlRoom = urlParams.get("room");
if (urlRoom) {
    roomCodeInput.value = urlRoom;
}

const savedUsername = localStorage.getItem("purestream_username");
if (savedUsername) {
    if (createUsernameInput) createUsernameInput.value = savedUsername;
    if (joinUsernameInput) joinUsernameInput.value = savedUsername;
}

if (createRoomBtn) {
    createRoomBtn.onclick = async () => {
        const username = createUsernameInput.value.trim();
        if (!username) {
            showToast("Please enter a username", "error");
            return;
        }
        localStorage.setItem("purestream_username", username);

        try {
            const res = await fetch(`${BACKEND_URL}/new-room`);
            const data = await res.json();
            enterRoom(data.room_id, username);
        } catch (e) {
            showToast("Error creating room", "error");
            console.error(e);
        }
    };
}

if (joinRoomBtn) {
    joinRoomBtn.onclick = () => {
        const username = joinUsernameInput.value.trim();
        if (!username) {
            showToast("Please enter a username", "error");
            return;
        }
        localStorage.setItem("purestream_username", username);

        const code = roomCodeInput.value.trim();
        if (!code) {
            showToast("Please enter a Room ID", "error");
            return;
        }
        enterRoom(code, username);
    };
}

function enterRoom(roomId: string, username: string): void {
    window.location.href = getRelativePath(`/viewer.html?room=${roomId}&username=${encodeURIComponent(username)}`);
}
